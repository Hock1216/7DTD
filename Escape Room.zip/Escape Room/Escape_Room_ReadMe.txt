To install Hock1216's 7DTD Escape Room:

1. Locate your saved game file location. By default, 7DTD game files are located at C:/Users/[YourUserName]/AppData/Roaming/7DaysToDie/Saves
	-> By default, Windows hides the AppData folder. To unhide, select the "View" option from the tabs at the top of your Windows Explorer window
	   and check mark the box to show "Hidden items".
2. Ensure you have a folder titled Navezgane at this path
	-> If you don't already have a Navezgane folder at this filepath, create one now by right-clicking and selecting New > Folder and naming it Navezgane.
2. Download the game file from GitHub if you haven't already: https://github.com/Hock1216/7DTD/raw/main/Escape%20Room.zip
3. Extract the game files by right-clicking and selecting "Extract All". Choose the extraction filepath as C:/Users/[YourUserName]/AppData/Roaming/7DaysToDie/Saves/Navezgane.
4. Launch 7 Days to Die and select the Main Menu option to "Continue Game." 
	-> If your file was correctly downloaded/extracted and placed at the correct location, you should see a game titled "Escape Room".
5. Once in the game, teleport to the escape room location at 317 W, 1779 N (for additional instructions at teleporting, see below)
	-> The Escape Room is the Navezgane High School. The entryway is at the front of the building behind the bus.
6. Discard all items from your inventory outside of the school. All necessary items will be given on entrance to the school.
7. Read the rules that are included in the school lobby.
8. Have fun!


To teleport:
	1. Open the command prompt with your key bindings. The default key binding for the command prompt is F1. Otherwise consult your in-game Options menu to 
	   find your Global > Console key binding.
	2. Enter the command line "tp -317 1779" (no quotes) and press Enter.
----OR-----
If you're more familiar with the POI prompt menu:
	1. Open the command prompt as noted above.
	2. Enter command line "tppoi" (no quotes) and press Enter.
	3. Page to "school_01" and Click on that option
		-> Note that this option will place you behind the school, so you will need to circle to the front to access the entryway.